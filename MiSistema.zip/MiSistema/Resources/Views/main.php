<!DOCTYPE html>
<html>
<head>
	<title>Principal</title>
</head>
<body style="background: linear-gradient(to right, rgba(0,255,0,0), rgba(0,255,200,1));">
	<h1 style="color: #888;">LaraCode</h1>
	<p><h4>Bienvenido</h4></p>
</body>
</html>